#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🔍 Validating Chrome Extension Structure...\n');

// Required files for Chrome Extension
const requiredFiles = [
  'manifest.json',
  'popup.html',
  'popup.js',
  'content.js',
  'content.css',
  'background.js',
  'icons/icon16.png',
  'icons/icon32.png',
  'icons/icon48.png',
  'icons/icon128.png'
];

let allValid = true;

// Check if all required files exist
requiredFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ Missing: ${file}`);
    allValid = false;
  }
});

// Validate manifest.json
console.log('\n📋 Validating manifest.json...');
try {
  const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
  
  const requiredFields = [
    'manifest_version',
    'name',
    'version',
    'permissions',
    'action',
    'content_scripts'
  ];
  
  requiredFields.forEach(field => {
    if (manifest[field]) {
      console.log(`✅ manifest.${field}`);
    } else {
      console.log(`❌ Missing: manifest.${field}`);
      allValid = false;
    }
  });
  
  // Check manifest version
  if (manifest.manifest_version === 3) {
    console.log('✅ Using Manifest V3 (recommended)');
  } else {
    console.log('⚠️ Not using Manifest V3');
  }
  
} catch (error) {
  console.log('❌ Invalid manifest.json:', error.message);
  allValid = false;
}

// Check file sizes for icons
console.log('\n🖼️ Checking icon files...');
const iconSizes = [16, 32, 48, 128];
iconSizes.forEach(size => {
  const iconPath = `icons/icon${size}.png`;
  if (fs.existsSync(iconPath)) {
    const stats = fs.statSync(iconPath);
    console.log(`✅ icon${size}.png (${stats.size} bytes)`);
  }
});

// Validate HTML structure
console.log('\n📄 Validating HTML structure...');
try {
  const htmlContent = fs.readFileSync('popup.html', 'utf8');
  
  const requiredElements = [
    '<html>',
    '<head>',
    '<body>',
    'popup.js'
  ];
  
  requiredElements.forEach(element => {
    if (htmlContent.includes(element)) {
      console.log(`✅ Contains: ${element}`);
    } else {
      console.log(`❌ Missing: ${element}`);
      allValid = false;
    }
  });
  
} catch (error) {
  console.log('❌ Error reading popup.html:', error.message);
  allValid = false;
}

// Check JavaScript files for basic structure
console.log('\n🔧 Validating JavaScript files...');
const jsFiles = ['popup.js', 'content.js', 'background.js'];

jsFiles.forEach(file => {
  try {
    const content = fs.readFileSync(file, 'utf8');
    if (content.length > 0) {
      console.log(`✅ ${file} (${content.length} characters)`);
    } else {
      console.log(`❌ ${file} is empty`);
      allValid = false;
    }
  } catch (error) {
    console.log(`❌ Error reading ${file}:`, error.message);
    allValid = false;
  }
});

// Final validation result
console.log('\n' + '='.repeat(50));
if (allValid) {
  console.log('🎉 Extension validation PASSED!');
  console.log('📦 Your extension is ready to be loaded in Chrome!');
  console.log('\nNext steps:');
  console.log('1. Open Chrome and go to chrome://extensions/');
  console.log('2. Enable Developer mode');
  console.log('3. Click "Load unpacked" and select this folder');
} else {
  console.log('❌ Extension validation FAILED!');
  console.log('Please fix the issues above before loading the extension.');
  process.exit(1);
}
