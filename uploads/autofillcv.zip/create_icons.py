#!/usr/bin/env python3

from PIL import Image, ImageDraw, ImageFont
import os

def create_icon(size, filename):
    # Create a new image with transparent background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Define colors - gradient effect simulation
    primary_color = (102, 126, 234)  # #667eea
    secondary_color = (118, 75, 162)  # #764ba2
    
    # Draw background circle with gradient-like effect
    for i in range(size//2):
        alpha = int(255 * (1 - i / (size//2)))
        color = tuple(int(primary_color[j] + (secondary_color[j] - primary_color[j]) * i / (size//2)) 
                     for j in range(3)) + (alpha,)
        draw.ellipse([i, i, size-i, size-i], fill=color)
    
    # Draw the main icon shape - a form/document icon
    margin = size // 6
    form_width = size - 2 * margin
    form_height = int(form_width * 1.3)
    
    if form_height > size - 2 * margin:
        form_height = size - 2 * margin
        form_width = int(form_height / 1.3)
    
    form_x = (size - form_width) // 2
    form_y = (size - form_height) // 2
    
    # Draw document background
    draw.rectangle([form_x, form_y, form_x + form_width, form_y + form_height], 
                   fill=(255, 255, 255, 220), outline=(200, 200, 200, 255), width=1)
    
    # Draw form lines
    line_count = 3 if size >= 32 else 2
    line_spacing = form_height // (line_count + 1)
    line_width = form_width - 8
    
    for i in range(line_count):
        y = form_y + line_spacing * (i + 1)
        draw.rectangle([form_x + 4, y - 1, form_x + 4 + line_width, y + 1], 
                      fill=(100, 100, 100, 180))
    
    # Add a small target/fill icon in the corner
    if size >= 32:
        target_size = size // 5
        target_x = form_x + form_width - target_size
        target_y = form_y
        
        # Draw target circles
        draw.ellipse([target_x, target_y, target_x + target_size, target_y + target_size], 
                    fill=(255, 193, 7, 200))
        draw.ellipse([target_x + 2, target_y + 2, target_x + target_size - 2, target_y + target_size - 2], 
                    fill=(255, 255, 255, 255))
        
        # Draw center dot
        center_size = target_size // 3
        center_x = target_x + (target_size - center_size) // 2
        center_y = target_y + (target_size - center_size) // 2
        draw.ellipse([center_x, center_y, center_x + center_size, center_y + center_size], 
                    fill=(255, 193, 7, 255))
    
    # Save the image
    img.save(filename, 'PNG')
    print(f"Created {filename} ({size}x{size})")

def main():
    # Create icons directory if it doesn't exist
    os.makedirs('icons', exist_ok=True)
    
    # Create icons in different sizes
    sizes = [16, 32, 48, 128]
    
    for size in sizes:
        create_icon(size, f'icons/icon{size}.png')
    
    print("All icons created successfully!")

if __name__ == "__main__":
    main()