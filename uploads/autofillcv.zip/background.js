// Background script for Chrome Extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('Job Application Auto-Filler installed');
});

// Handle messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getData') {
    chrome.storage.sync.get(null, (data) => {
      sendResponse(data);
    });
    return true; // Will respond asynchronously
  }
  
  if (request.action === 'saveData') {
    chrome.storage.sync.set(request.data, () => {
      sendResponse({ success: true });
    });
    return true; // Will respond asynchronously
  }
});

// Context menu for quick access (optional feature)
if (chrome.contextMenus) {
  chrome.contextMenus.create({
    id: 'autoFillForms',
    title: 'Auto-fill job application forms',
    contexts: ['page']
  });

  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'autoFillForms') {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: () => {
          window.postMessage({ type: 'AUTO_FILL_REQUEST' }, '*');
        }
      });
    }
  });
}

// Badge text to show extension status
if (chrome.tabs && chrome.action) {
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    try {
      chrome.storage.sync.get(['firstName'], (data) => {
        if (data.firstName) {
          chrome.action.setBadgeText({
            tabId: activeInfo.tabId,
            text: '✓'
          });
          chrome.action.setBadgeBackgroundColor({
            tabId: activeInfo.tabId,
            color: '#4CAF50'
          });
        } else {
          chrome.action.setBadgeText({
            tabId: activeInfo.tabId,
            text: '!'
          });
          chrome.action.setBadgeBackgroundColor({
            tabId: activeInfo.tabId,
            color: '#FF9800'
          });
        }
      });
    } catch (error) {
      console.log('Badge update error:', error);
    }
  });
}