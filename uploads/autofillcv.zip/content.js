// Content script for auto-filling forms
class JobApplicationAutoFiller {
  constructor() {
    this.userData = null;
    this.init();
  }
  
  init() {
    // Listen for messages from popup
    window.addEventListener('message', (event) => {
      if (event.data.type === 'AUTO_FILL_REQUEST') {
        this.loadDataAndFill();
      }
    });
    
    // Create floating action button
    this.createFloatingButton();
  }
  
  async loadDataAndFill() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(null, (data) => {
        this.userData = data;
        this.fillForms();
        resolve();
      });
    });
  }
  
  createFloatingButton() {
    // Only create button if forms are detected
    if (this.detectForms()) {
      const button = document.createElement('div');
      button.id = 'job-autofill-btn';
      button.innerHTML = '🎯';
      button.title = 'Auto-fill job application';
      button.className = 'job-autofill-floating-btn';
      
      button.addEventListener('click', () => {
        this.loadDataAndFill();
      });
      
      document.body.appendChild(button);
    }
  }
  
  detectForms() {
    const forms = document.querySelectorAll('form');
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea');
    return forms.length > 0 || inputs.length > 3;
  }
  
  fillForms() {
    if (!this.userData) return;
    
    // Enhanced field mapping with more comprehensive patterns
    const fieldMappings = {
      // Name fields - much more comprehensive
      firstName: [
        // Standard patterns
        'input[name*="first" i][name*="name" i]',
        'input[id*="first" i][id*="name" i]',
        'input[placeholder*="first" i][placeholder*="name" i]',
        'input[name="fname"]', 'input[id="fname"]',
        'input[name="firstName"]', 'input[id="firstName"]',
        'input[name="first_name"]', 'input[id="first_name"]',
        // Alternative patterns
        'input[name*="given" i][name*="name" i]',
        'input[name*="forename" i]', 'input[id*="forename" i]',
        'input[name="f_name"]', 'input[id="f_name"]',
        'input[aria-label*="first" i][aria-label*="name" i]',
        'input[data-field*="first" i]', 'input[data-name*="first" i]',
        // Form builder patterns
        'input[name*="field" i][placeholder*="first" i]',
        'input[class*="first" i][class*="name" i]',
        // International patterns
        'input[placeholder*="prénom" i]', // French
        'input[placeholder*="vorname" i]', // German
        'input[placeholder*="nombre" i]', // Spanish
        // Generic name fields that could be first name
        'input[name="name1"]', 'input[id="name1"]',
        'input[name*="applicant" i][name*="first" i]'
      ],
      
      lastName: [
        // Standard patterns
        'input[name*="last" i][name*="name" i]',
        'input[id*="last" i][id*="name" i]',
        'input[placeholder*="last" i][placeholder*="name" i]',
        'input[name="lname"]', 'input[id="lname"]',
        'input[name="lastName"]', 'input[id="lastName"]',
        'input[name="last_name"]', 'input[id="last_name"]',
        // Alternative patterns
        'input[name*="family" i][name*="name" i]',
        'input[name*="surname" i]', 'input[id*="surname" i]',
        'input[name="l_name"]', 'input[id="l_name"]',
        'input[aria-label*="last" i][aria-label*="name" i]',
        'input[data-field*="last" i]', 'input[data-name*="last" i]',
        // Form builder patterns
        'input[name*="field" i][placeholder*="last" i]',
        'input[class*="last" i][class*="name" i]',
        // International patterns
        'input[placeholder*="nom" i]', // French
        'input[placeholder*="nachname" i]', // German
        'input[placeholder*="apellido" i]', // Spanish
        // Generic patterns
        'input[name="name2"]', 'input[id="name2"]',
        'input[name*="applicant" i][name*="last" i]'
      ],
      
      // Full name field - comprehensive patterns
      fullName: [
        'input[name="name"]:not([name*="first" i]):not([name*="last" i]):not([name*="user" i]):not([name*="company" i])',
        'input[id="name"]:not([id*="first" i]):not([id*="last" i]):not([id*="user" i]):not([id*="company" i])',
        'input[name="fullname"]', 'input[id="fullname"]',
        'input[name="full_name"]', 'input[id="full_name"]',
        'input[name="fullName"]', 'input[id="fullName"]',
        'input[placeholder*="full" i][placeholder*="name" i]',
        'input[placeholder*="your" i][placeholder*="name" i]',
        'input[placeholder*="complete" i][placeholder*="name" i]',
        'input[name*="applicant" i][name*="name" i]',
        'input[name*="candidate" i][name*="name" i]',
        'input[aria-label*="full" i][aria-label*="name" i]',
        'input[data-field="name"]', 'input[data-name="name"]'
      ],
      
      // Email fields - comprehensive patterns
      email: [
        'input[type="email"]',
        'input[name*="email" i]', 'input[id*="email" i]',
        'input[placeholder*="email" i]',
        'input[name*="mail" i]:not([name*="gmail" i])',
        'input[id*="mail" i]:not([id*="gmail" i])',
        'input[name="e_mail"]', 'input[id="e_mail"]',
        'input[name="emailAddress"]', 'input[id="emailAddress"]',
        'input[name="email_address"]', 'input[id="email_address"]',
        'input[aria-label*="email" i]',
        'input[data-field*="email" i]',
        'input[class*="email" i]',
        'input[placeholder*="@" i]',
        'input[name*="contact" i][name*="email" i]',
        'input[name*="work" i][name*="email" i]',
        'input[name*="personal" i][name*="email" i]'
      ],
      
      // Phone fields - comprehensive patterns
      phone: [
        'input[type="tel"]',
        'input[name*="phone" i]', 'input[id*="phone" i]',
        'input[placeholder*="phone" i]',
        'input[name*="mobile" i]', 'input[id*="mobile" i]',
        'input[name*="cell" i]', 'input[id*="cell" i]',
        'input[name*="tel" i]', 'input[id*="tel" i]',
        'input[name="phoneNumber"]', 'input[id="phoneNumber"]',
        'input[name="phone_number"]', 'input[id="phone_number"]',
        'input[name="telephone"]', 'input[id="telephone"]',
        'input[aria-label*="phone" i]',
        'input[data-field*="phone" i]',
        'input[placeholder*="mobile" i]',
        'input[placeholder*="cell" i]',
        'input[placeholder*="contact" i][placeholder*="number" i]',
        'input[name*="contact" i][name*="number" i]',
        'input[class*="phone" i]'
      ],
      
      // Address fields - comprehensive patterns
      address: [
        'input[name*="address" i]', 'input[id*="address" i]',
        'input[placeholder*="address" i]',
        'textarea[name*="address" i]', 'textarea[id*="address" i]',
        'input[name*="street" i]', 'input[id*="street" i]',
        'input[name*="location" i]', 'input[id*="location" i]',
        'input[name="addr"]', 'input[id="addr"]',
        'input[name="address1"]', 'input[id="address1"]',
        'input[name="street_address"]', 'input[id="street_address"]',
        'input[aria-label*="address" i]',
        'input[data-field*="address" i]',
        'input[placeholder*="street" i]',
        'input[placeholder*="home" i][placeholder*="address" i]',
        'input[class*="address" i]'
      ],
      
      // LinkedIn fields - comprehensive patterns
      linkedin: [
        'input[name*="linkedin" i]', 'input[id*="linkedin" i]',
        'input[placeholder*="linkedin" i]',
        'input[name*="social" i][name*="media" i]',
        'input[name*="professional" i][name*="profile" i]',
        'input[placeholder*="linkedin.com" i]',
        'input[name*="profile" i][name*="url" i]',
        'input[aria-label*="linkedin" i]',
        'input[data-field*="linkedin" i]',
        'input[name*="social" i][name*="link" i]',
        'input[placeholder*="professional" i][placeholder*="network" i]'
      ],
      
      // Portfolio/Website fields
      portfolio: [
        'input[name*="website" i]', 'input[id*="website" i]',
        'input[name*="portfolio" i]', 'input[id*="portfolio" i]',
        'input[placeholder*="website" i]',
        'input[placeholder*="portfolio" i]',
        'input[name*="personal" i][name*="site" i]',
        'input[name*="personal" i][name*="website" i]',
        'input[name*="web" i][name*="site" i]',
        'input[aria-label*="website" i]',
        'input[aria-label*="portfolio" i]',
        'input[data-field*="website" i]',
        'input[placeholder*="personal" i][placeholder*="site" i]'
      ],
      
      // Position/Title fields - enhanced
      currentPosition: [
        'input[name*="position" i]', 'input[id*="position" i]',
        'input[name*="title" i]', 'input[id*="title" i]',
        'input[name*="job" i][name*="title" i]',
        'input[name*="current" i][name*="role" i]',
        'input[name*="current" i][name*="position" i]',
        'input[placeholder*="position" i]',
        'input[placeholder*="title" i]',
        'input[placeholder*="current" i][placeholder*="role" i]',
        'input[name*="role" i]', 'input[id*="role" i]',
        'input[name*="designation" i]', 'input[id*="designation" i]',
        'input[aria-label*="position" i]',
        'input[aria-label*="job" i][aria-label*="title" i]',
        'input[data-field*="position" i]',
        'input[name*="work" i][name*="title" i]',
        'input[name*="employment" i][name*="title" i]'
      ],
      
      // Company fields - enhanced
      currentCompany: [
        'input[name*="company" i]', 'input[id*="company" i]',
        'input[name*="employer" i]', 'input[id*="employer" i]',
        'input[placeholder*="company" i]',
        'input[placeholder*="employer" i]',
        'input[name*="organization" i]', 'input[id*="organization" i]',
        'input[name*="current" i][name*="company" i]',
        'input[name*="current" i][name*="employer" i]',
        'input[name*="work" i][name*="company" i]',
        'input[aria-label*="company" i]',
        'input[aria-label*="employer" i]',
        'input[data-field*="company" i]',
        'input[placeholder*="organization" i]',
        'input[name*="firm" i]', 'input[id*="firm" i]'
      ],
      
      // Experience/Date fields - enhanced for new structure
      startDate: [
        'input[name*="start" i][name*="date" i]',
        'input[id*="start" i][id*="date" i]',
        'input[name*="from" i][name*="date" i]',
        'input[name*="begin" i][name*="date" i]',
        'input[placeholder*="start" i][placeholder*="date" i]',
        'input[type="date"][name*="start" i]',
        'input[type="month"][name*="start" i]',
        'input[name*="employment" i][name*="start" i]',
        'input[name*="work" i][name*="start" i]'
      ],
      
      endDate: [
        'input[name*="end" i][name*="date" i]',
        'input[id*="end" i][id*="date" i]',
        'input[name*="to" i][name*="date" i]',
        'input[name*="until" i][name*="date" i]',
        'input[placeholder*="end" i][placeholder*="date" i]',
        'input[type="date"][name*="end" i]',
        'input[type="month"][name*="end" i]',
        'input[name*="employment" i][name*="end" i]',
        'input[name*="work" i][name*="end" i]'
      ],
      
      // Skills fields - enhanced
      skills: [
        'textarea[name*="skill" i]', 'textarea[id*="skill" i]',
        'textarea[placeholder*="skill" i]',
        'input[name*="skill" i]', 'input[id*="skill" i]',
        'textarea[name*="competenc" i]', 'textarea[id*="competenc" i]',
        'textarea[name*="technical" i]', 'textarea[id*="technical" i]',
        'textarea[name*="expertise" i]', 'textarea[id*="expertise" i]',
        'input[name*="technologies" i]', 'input[id*="technologies" i]',
        'textarea[name*="technologies" i]', 'textarea[id*="technologies" i]',
        'textarea[aria-label*="skill" i]',
        'textarea[data-field*="skill" i]',
        'input[placeholder*="skill" i]',
        'textarea[placeholder*="technical" i]',
        'textarea[name*="abilities" i]'
      ],
      
      // Education fields - enhanced
      education: [
        'input[name*="education" i]', 'input[id*="education" i]',
        'input[name*="degree" i]', 'input[id*="degree" i]',
        'input[placeholder*="education" i]',
        'input[placeholder*="degree" i]',
        'select[name*="education" i]', 'select[id*="education" i]',
        'input[name*="qualification" i]', 'input[id*="qualification" i]',
        'input[name*="university" i]', 'input[id*="university" i]',
        'input[name*="college" i]', 'input[id*="college" i]',
        'input[name*="school" i]', 'input[id*="school" i]',
        'textarea[name*="education" i]', 'textarea[id*="education" i]',
        'input[aria-label*="education" i]',
        'input[data-field*="education" i]',
        'input[name*="academic" i]', 'input[id*="academic" i]'
      ],
      
      // Cover letter fields - enhanced
      coverLetter: [
        'textarea[name*="cover" i]', 'textarea[id*="cover" i]',
        'textarea[name*="letter" i]', 'textarea[id*="letter" i]',
        'textarea[placeholder*="cover" i]',
        'textarea[placeholder*="letter" i]',
        'textarea[name*="message" i]', 'textarea[id*="message" i]',
        'textarea[name*="why" i][name*="interested" i]',
        'textarea[name*="motivation" i]', 'textarea[id*="motivation" i]',
        'textarea[name*="personal" i][name*="statement" i]',
        'textarea[aria-label*="cover" i]',
        'textarea[aria-label*="letter" i]',
        'textarea[data-field*="cover" i]',
        'textarea[placeholder*="why" i][placeholder*="apply" i]',
        'textarea[name*="additional" i][name*="information" i]'
      ],
      
      // Resume/CV upload fields
      resume: [
        'input[type="file"][name*="resume" i]',
        'input[type="file"][name*="cv" i]',
        'input[type="file"][id*="resume" i]',
        'input[type="file"][id*="cv" i]',
        'input[type="file"][name*="upload" i][name*="resume" i]'
      ]
    };
    
    let filledFields = 0;
    
    // Fill each field type
    Object.keys(fieldMappings).forEach(dataKey => {
      let valueToFill = '';
      
      // Handle different data sources
      if (dataKey === 'fullName') {
        valueToFill = `${this.userData.firstName || ''} ${this.userData.lastName || ''}`.trim();
      } else if (dataKey === 'currentPosition' && this.userData.experiences && this.userData.experiences[0]) {
        valueToFill = this.userData.experiences[0].position;
      } else if (dataKey === 'currentCompany' && this.userData.experiences && this.userData.experiences[0]) {
        valueToFill = this.userData.experiences[0].company;
      } else if (dataKey === 'startDate' && this.userData.experiences && this.userData.experiences[0]) {
        valueToFill = this.userData.experiences[0].startDate;
      } else if (dataKey === 'endDate' && this.userData.experiences && this.userData.experiences[0]) {
        valueToFill = this.userData.experiences[0].endDate;
      } else {
        valueToFill = this.userData[dataKey];
      }
      
      if (valueToFill) {
        const selectors = fieldMappings[dataKey];
        
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          if (element && !element.value && !element.disabled && element.offsetParent !== null) {
            // Fill the field
            if (element.tagName.toLowerCase() === 'select') {
              this.fillSelectField(element, valueToFill);
            } else if (element.type === 'file') {
              // Skip file inputs for now
              continue;
            } else {
              element.value = valueToFill;
              
              // Trigger events to notify frameworks
              element.dispatchEvent(new Event('input', { bubbles: true }));
              element.dispatchEvent(new Event('change', { bubbles: true }));
              element.dispatchEvent(new Event('blur', { bubbles: true }));
              
              // Additional events for complex frameworks
              element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
              element.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
            }
            
            filledFields++;
            break; // Stop after filling the first matching field
          }
        }
      }
    });
    
    // Show notification
    this.showNotification(`Auto-filled ${filledFields} fields!`);
  }
  
  fillSelectField(selectElement, value) {
    const options = selectElement.options;
    for (let i = 0; i < options.length; i++) {
      if (options[i].text.toLowerCase().includes(value.toLowerCase()) ||
          options[i].value.toLowerCase().includes(value.toLowerCase())) {
        selectElement.selectedIndex = i;
        selectElement.dispatchEvent(new Event('change', { bubbles: true }));
        break;
      }
    }
  }
  
  showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'job-autofill-notification';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Show animation
    setTimeout(() => {
      notification.classList.add('show');
    }, 100);
    
    // Hide after 3 seconds
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }
}

// Initialize the auto-filler when the page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new JobApplicationAutoFiller();
  });
} else {
  new JobApplicationAutoFiller();
}