document.addEventListener('DOMContentLoaded', function() {
  // Tab switching functionality
  const tabs = document.querySelectorAll('.tab');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(tc => tc.classList.remove('active'));
      
      tab.classList.add('active');
      document.getElementById(tab.dataset.tab).classList.add('active');
    });
  });
  
  // Load saved data when popup opens
  loadSavedData();
  
  // Event listeners for buttons
  document.getElementById('saveBtn').addEventListener('click', saveData);
  document.getElementById('fillBtn').addEventListener('click', fillForms);
  document.getElementById('clearBtn').addEventListener('click', clearData);
  document.getElementById('addExperienceBtn').addEventListener('click', addExperienceEntry);
  
  // Resume upload functionality
  document.getElementById('resumeUpload').addEventListener('change', handleResumeUpload);
  document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-remove-file')) {
      removeResumeFile();
    }
    if (e.target.classList.contains('btn-remove-experience')) {
      removeExperienceEntry(e.target.closest('.experience-entry'));
    }
  });
  
  // Auto-save on input change
  const inputs = document.querySelectorAll('input, textarea');
  inputs.forEach(input => {
    input.addEventListener('input', debounce(autoSave, 1000));
  });
  
  // Add initial experience entry if none exist
  setTimeout(() => {
    if (document.querySelectorAll('.experience-entry').length === 0) {
      addExperienceEntry();
    }
  }, 100);
});

function loadSavedData() {
  chrome.storage.sync.get(null, function(data) {
    // Personal information
    if (data.firstName) document.getElementById('firstName').value = data.firstName;
    if (data.lastName) document.getElementById('lastName').value = data.lastName;
    if (data.email) document.getElementById('email').value = data.email;
    if (data.phone) document.getElementById('phone').value = data.phone;
    if (data.address) document.getElementById('address').value = data.address;
    if (data.linkedin) document.getElementById('linkedin').value = data.linkedin;
    if (data.portfolio) document.getElementById('portfolio').value = data.portfolio;
    
    // Experience and other fields
    if (data.skills) document.getElementById('skills').value = data.skills;
    if (data.education) document.getElementById('education').value = data.education;
    if (data.coverLetter) document.getElementById('coverLetter').value = data.coverLetter;
    
    // Resume fields
    if (data.resumeText) document.getElementById('resumeText').value = data.resumeText;
    if (data.linkedinProfile) document.getElementById('linkedinProfile').value = data.linkedinProfile;
    if (data.githubProfile) document.getElementById('githubProfile').value = data.githubProfile;
    if (data.certifications) document.getElementById('certifications').value = data.certifications;
    
    // Load experience entries
    if (data.experiences && data.experiences.length > 0) {
      data.experiences.forEach(exp => {
        addExperienceEntry(exp);
      });
    } else {
      addExperienceEntry(); // Add default empty entry
    }
    
    // Load resume file info
    if (data.resumeFileName) {
      showFileInfo(data.resumeFileName);
    }
  });
}

function saveData() {
  const data = {
    firstName: document.getElementById('firstName').value,
    lastName: document.getElementById('lastName').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value,
    linkedin: document.getElementById('linkedin').value,
    portfolio: document.getElementById('portfolio').value,
    skills: document.getElementById('skills').value,
    education: document.getElementById('education').value,
    coverLetter: document.getElementById('coverLetter').value,
    resumeText: document.getElementById('resumeText').value,
    linkedinProfile: document.getElementById('linkedinProfile').value,
    githubProfile: document.getElementById('githubProfile').value,
    certifications: document.getElementById('certifications').value,
    experiences: getExperienceData(),
    resumeFileName: document.querySelector('.file-name')?.textContent || ''
  };
  
  chrome.storage.sync.set(data, function() {
    showStatus('Data saved successfully!', 'success');
  });
}

function autoSave() {
  const data = {
    firstName: document.getElementById('firstName').value,
    lastName: document.getElementById('lastName').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value,
    linkedin: document.getElementById('linkedin').value,
    portfolio: document.getElementById('portfolio').value,
    skills: document.getElementById('skills').value,
    education: document.getElementById('education').value,
    coverLetter: document.getElementById('coverLetter').value,
    resumeText: document.getElementById('resumeText').value,
    linkedinProfile: document.getElementById('linkedinProfile').value,
    githubProfile: document.getElementById('githubProfile').value,
    certifications: document.getElementById('certifications').value,
    experiences: getExperienceData(),
    resumeFileName: document.querySelector('.file-name')?.textContent || ''
  };
  
  chrome.storage.sync.set(data);
}

function fillForms() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.scripting.executeScript({
      target: {tabId: tabs[0].id},
      function: injectAutoFill
    }, (results) => {
      if (chrome.runtime.lastError) {
        showStatus('Error: Could not auto-fill forms', 'error');
      } else {
        showStatus('Forms auto-filled successfully!', 'success');
        window.close();
      }
    });
  });
}

function injectAutoFill() {
  // This function runs in the content script context
  window.postMessage({type: 'AUTO_FILL_REQUEST'}, '*');
}

function clearData() {
  if (confirm('Are you sure you want to clear all saved data?')) {
    chrome.storage.sync.clear(function() {
      // Clear all input fields
      const inputs = document.querySelectorAll('input, textarea');
      inputs.forEach(input => input.value = '');
      
      showStatus('All data cleared!', 'success');
    });
  }
}

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
  status.style.display = 'block';
  
  setTimeout(() => {
    status.style.display = 'none';
  }, 3000);
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Experience Management Functions
function addExperienceEntry(expData = null) {
  const container = document.getElementById('experienceContainer');
  const entryId = 'exp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
  
  const entryDiv = document.createElement('div');
  entryDiv.className = 'experience-entry';
  entryDiv.dataset.entryId = entryId;
  
  entryDiv.innerHTML = `
    <h4>
      <span>Experience ${container.children.length + 1}</span>
      <button type="button" class="btn-remove-experience">✕</button>
    </h4>
    
    <div class="form-group">
      <label>Position/Job Title:</label>
      <input type="text" class="exp-position" placeholder="e.g., Senior Software Developer" value="${expData?.position || ''}">
    </div>
    
    <div class="form-group">
      <label>Company:</label>
      <input type="text" class="exp-company" placeholder="e.g., Tech Solutions Inc." value="${expData?.company || ''}">
    </div>
    
    <div class="date-row">
      <div class="date-group">
        <label>Start Date:</label>
        <input type="month" class="exp-start-date" value="${expData?.startDate || ''}">
      </div>
      <div class="date-group">
        <label>End Date:</label>
        <input type="month" class="exp-end-date" value="${expData?.endDate || ''}" placeholder="Current">
      </div>
    </div>
    
    <div class="form-group">
      <label>Job Description:</label>
      <textarea class="exp-description" rows="3" placeholder="Describe your key responsibilities and achievements...">${expData?.description || ''}</textarea>
    </div>
  `;
  
  container.appendChild(entryDiv);
  
  // Add event listeners for auto-save
  entryDiv.querySelectorAll('input, textarea').forEach(input => {
    input.addEventListener('input', debounce(autoSave, 1000));
  });
  
  updateExperienceNumbers();
}

function removeExperienceEntry(entryElement) {
  entryElement.remove();
  updateExperienceNumbers();
  autoSave();
}

function updateExperienceNumbers() {
  const entries = document.querySelectorAll('.experience-entry');
  entries.forEach((entry, index) => {
    const span = entry.querySelector('h4 span');
    span.textContent = `Experience ${index + 1}`;
  });
}

function getExperienceData() {
  const experiences = [];
  document.querySelectorAll('.experience-entry').forEach(entry => {
    const exp = {
      position: entry.querySelector('.exp-position').value,
      company: entry.querySelector('.exp-company').value,
      startDate: entry.querySelector('.exp-start-date').value,
      endDate: entry.querySelector('.exp-end-date').value,
      description: entry.querySelector('.exp-description').value
    };
    if (exp.position || exp.company) { // Only save if has meaningful data
      experiences.push(exp);
    }
  });
  return experiences;
}

// Resume Upload Functions
function handleResumeUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  const allowedTypes = ['application/pdf', 'application/msword', 
                       'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
  
  if (!allowedTypes.includes(file.type)) {
    showStatus('Please upload a PDF or Word document', 'error');
    event.target.value = '';
    return;
  }
  
  if (file.size > 10 * 1024 * 1024) { // 10MB limit
    showStatus('File size must be less than 10MB', 'error');
    event.target.value = '';
    return;
  }
  
  showFileInfo(file.name);
  extractTextFromFile(file);
  autoSave();
}

function showFileInfo(fileName) {
  const fileInfo = document.getElementById('fileInfo');
  const fileNameSpan = fileInfo.querySelector('.file-name');
  
  fileNameSpan.textContent = fileName;
  fileInfo.style.display = 'flex';
}

function removeResumeFile() {
  document.getElementById('resumeUpload').value = '';
  document.getElementById('fileInfo').style.display = 'none';
  document.getElementById('resumeText').value = '';
  autoSave();
}

function extractTextFromFile(file) {
  const reader = new FileReader();
  
  if (file.type === 'application/pdf') {
    // For PDF files, we'll show a placeholder message
    // In a real implementation, you'd use a PDF parsing library
    document.getElementById('resumeText').value = 
      'PDF uploaded successfully. Text extraction from PDF requires additional libraries. ' +
      'Please copy and paste your resume text here manually for better auto-fill accuracy.';
  } else {
    // For Word documents, also show placeholder
    // Real implementation would require docx parsing
    document.getElementById('resumeText').value = 
      'Document uploaded successfully. For best results, please copy and paste your ' +
      'resume text here manually to ensure accurate auto-filling.';
  }
  
  reader.onload = function(e) {
    // Store file data if needed
    showStatus('Resume uploaded successfully!', 'success');
  };
  
  reader.readAsArrayBuffer(file);
}