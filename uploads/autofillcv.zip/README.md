# Job Application Auto-Filler Chrome Extension

🚀 **Save time filling out repetitive job applications!** This Chrome extension allows you to save your personal information once and auto-fill job application forms with a single click.

## Features

✨ **Smart Form Detection**: Automatically detects job application forms on any website  
💾 **Secure Data Storage**: Your data is stored locally in Chrome's secure storage  
🎯 **One-Click Auto-Fill**: Fill entire forms with a single click  
📄 **Resume Upload**: Upload PDF/DOC resume files for comprehensive data storage  
🔢 **Multiple Work Experiences**: Add unlimited work experience entries with start/end dates  
🔄 **Auto-Save**: Your data is automatically saved as you type  
📱 **Beautiful UI**: Modern, intuitive interface with tabbed organization  
🎨 **Floating Action Button**: Quick access button appears on pages with forms  
🔍 **Enhanced Field Recognition**: Recognizes 200+ field patterns across different websites and languages  
🛡️ **Privacy First**: All data stays on your computer - nothing is sent to external servers  
🌐 **International Support**: Recognizes field names in multiple languages (English, French, German, Spanish)  
⚡ **Framework Compatible**: Works with React, Angular, Vue.js, and other modern web frameworks

## Installation

### Method 1: Developer Mode (Recommended)

1. **Download the Extension**
   - Download all the files from this project
   - Keep them in a folder (e.g., `job-autofill-extension`)

2. **Open Chrome Extensions**
   - Go to `chrome://extensions/` in your Chrome browser
   - Or click the three dots menu → More tools → Extensions

3. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the Extension**
   - Click "Load unpacked"
   - Select the folder containing the extension files
   - The extension should now appear in your extensions list

### Method 2: Package and Install

1. **Package the Extension** (optional)
   - In Chrome Extensions page, click "Pack extension"
   - Select your extension folder
   - This creates a .crx file

2. **Install the Package**
   - Drag and drop the .crx file to the Extensions page

## Usage

### Setting Up Your Information

1. **Click the Extension Icon**
   - Look for the 🎯 icon in your Chrome toolbar
   - Click it to open the popup

2. **Fill in Your Information**
   - **Personal Tab**: Name, email, phone, address, LinkedIn, portfolio
   - **Experience Tab**: Current position, company, skills, education, cover letter
   - Your data is automatically saved as you type

3. **Save Your Data**
   - Click the "💾 Save Data" button to ensure everything is stored

### Auto-Filling Forms

#### Method 1: Extension Popup
1. Navigate to any job application page
2. Click the extension icon
3. Go to the "Actions" tab
4. Click "🎯 Auto Fill"

#### Method 2: Floating Button
1. Navigate to any job application page
2. Look for the floating 🎯 button (bottom-right corner)
3. Click it to auto-fill the forms

#### Method 3: Right-Click Menu
1. Right-click anywhere on a job application page
2. Select "Auto-fill job application forms"

### Supported Fields

The extension intelligently detects and fills these common fields with **enhanced pattern recognition**:

**Personal Information:**
- First Name / Last Name / Full Name (50+ patterns)
- Email Address (25+ patterns)
- Phone Number / Mobile / Telephone (20+ patterns)
- Address / Street Address / Location (15+ patterns)
- LinkedIn URL / Professional Profile (10+ patterns)
- Portfolio/Website URL / Personal Site (10+ patterns)

**Professional Information:**
- Current Position/Job Title/Role/Designation (20+ patterns)
- Current Company/Employer/Organization/Firm (15+ patterns)
- Work Start Date / Employment Begin Date (10+ patterns)
- Work End Date / Employment End Date (10+ patterns)
- Job Description / Responsibilities (5+ patterns)
- Skills / Technical Skills / Competencies / Expertise (15+ patterns)
- Education/Degree/Qualification/Academic Background (20+ patterns)

**Additional Information:**
- Cover Letter / Motivation Letter / Personal Statement (15+ patterns)
- Resume/CV Upload (file input detection)
- Certifications / Professional Certifications
- GitHub Profile / Code Repository
- Multiple Work Experience Entries (unlimited)

**Enhanced Recognition Features:**
- **Multi-language Support**: English, French, German, Spanish field names
- **Framework Compatibility**: React, Angular, Vue.js, jQuery forms
- **Alternative Naming**: Handles fname/lname, emailAddress, phoneNumber, etc.
- **Placeholder Detection**: Recognizes fields by placeholder text
- **ARIA Label Support**: Accessibility-compliant form detection
- **Data Attribute Recognition**: Custom data-field and data-name attributes
- **Class-based Detection**: CSS class name pattern matching

## File Structure

```
job-autofill-extension/
├── manifest.json          # Extension configuration
├── popup.html             # Extension popup interface
├── popup.js              # Popup functionality
├── content.js            # Form detection and auto-fill logic
├── content.css           # Styles for floating button and notifications
├── background.js         # Background service worker
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md            # This file
```

## Technical Details

### Permissions Used

- **`storage`**: Store your personal information securely in Chrome
- **`activeTab`**: Access the current tab to fill forms
- **`scripting`**: Inject scripts to detect and fill forms

### Data Storage

- All data is stored locally using Chrome's `chrome.storage.sync` API
- Data syncs across your Chrome browsers when signed in
- No external servers - your privacy is protected

### Form Detection Algorithm

The extension uses intelligent pattern matching to detect form fields:
- Searches for common field names, IDs, and placeholders
- Supports multiple languages and naming conventions
- Handles various form structures and frameworks

## Privacy & Security

🔒 **Your data never leaves your browser**
- No external API calls or data transmission
- All processing happens locally
- Chrome's secure storage ensures data protection

## Troubleshooting

### Extension Not Working?

1. **Check Permissions**
   - Make sure the extension has necessary permissions
   - Refresh the page and try again

2. **Forms Not Detected**
   - The extension looks for forms and input fields
   - Some heavily customized forms might not be detected
   - Try clicking in a form field first

3. **Data Not Saving**
   - Check if Chrome sync is enabled
   - Clear browser cache and try again

### Fields Not Filling?

1. **Check Field Names**
   - The extension matches common field patterns
   - Custom field names might not be recognized
   - You can manually fill missed fields

2. **JavaScript-Heavy Sites**
   - Some sites use complex JavaScript
   - Try waiting for the page to fully load
   - Refresh and try again

## Contributing

Found a bug or want to add a feature?

1. **Report Issues**: Describe the problem and what site it occurred on
2. **Feature Requests**: Suggest new field types or functionality
3. **Code Contributions**: Submit pull requests with improvements

## Browser Compatibility

- ✅ Chrome (Manifest V3)
- ✅ Chromium-based browsers (Edge, Brave, etc.)
- ❌ Firefox (would need Manifest V2 version)

## Version History

### v1.0.0
- Initial release
- Basic auto-fill functionality
- Secure data storage
- Floating action button
- Context menu integration

## Support

Need help? Here are some resources:

1. **Check Common Issues**: Review the troubleshooting section
2. **Test on Different Sites**: Try various job board websites
3. **Browser Console**: Check for error messages in developer tools

## License

This project is open source and available under the MIT License.

---

**Happy job hunting! 🎯 May this extension help you land your dream job faster!**